package com.nemanjamiseljic.dogoapp.models.breeds

class Breeds : ArrayList<BreedsItem>()