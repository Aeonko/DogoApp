package com.nemanjamiseljic.dogoapp.models.breeds

data class Height(
    val imperial: String,
    val metric: String
)