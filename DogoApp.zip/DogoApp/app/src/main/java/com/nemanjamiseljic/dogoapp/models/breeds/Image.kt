package com.nemanjamiseljic.dogoapp.models.breeds

data class Image(
    val height: Int,
    val id: String,
    val url: String,
    val width: Int
)