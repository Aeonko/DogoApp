package com.nemanjamiseljic.dogoapp.models.breeds

data class Weight(
    val imperial: String,
    val metric: String
)