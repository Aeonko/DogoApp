package com.nemanjamiseljic.dogoapp.models.selectedbreeds

data class Height(
    val imperial: String,
    val metric: String
)