package com.nemanjamiseljic.dogoapp.models.selectedbreeds

class SelectedBreed : ArrayList<SelectedBreedItem>()