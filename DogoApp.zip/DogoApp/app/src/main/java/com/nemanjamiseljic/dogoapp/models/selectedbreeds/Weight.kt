package com.nemanjamiseljic.dogoapp.models.selectedbreeds

data class Weight(
    val imperial: String,
    val metric: String
)