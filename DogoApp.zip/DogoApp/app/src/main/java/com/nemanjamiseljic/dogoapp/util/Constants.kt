package com.nemanjamiseljic.dogoapp.util

object Constants {

    const val API_KEY = "7b8baa58-9fa3-4109-b927-02b7b0b12c01"
    const val BASE_URL = "https://api.thedogapi.com/v1/"
}